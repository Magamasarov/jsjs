// Циклы while и for
for i in range(1, 101):
    print(i)


//1
num = 11
while num <= 33:
    print(num)
    num += 1


//2
for i in range(0, 101, 2):
    print(i)


//3
sum_numbers = 0
current_number = 1

while current_number <= 100:
    sum_numbers += current_number
    current_number += 1

print("Сумма чисел от 1 до 100:", sum_numbers)






////Работа с for для массивов

//1
my_array = [1, 2, 3, 4, 5]

for element in my_array:
    print(element)


//2
my_array = [1, 2, 3, 4, 5]
result = 0

for element in my_array:
    result += element

print("Сумма элементов массива:", result)


////Работа с for-in

//1
var obj = {green: 'зеленый', red: 'красный', blue: 'голубой'};

for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
        console.log('Ключ: ' + key + ', Элемент: ' + obj[key]);
    }
}


//2
var obj = {Коля: '200', Вася: '300', Петя: '400'};

for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
        console.log(key + ' - зарплата ' + obj[key] + ' долларов.');
    }
}





////Задачи

//2
var array1 = [2, 5, 9, 15, 0, 4];

for (var i = 0; i < array1.length; i++) {
    if (array1[i] > 3 && array1[i] < 10) {
        console.log(array1[i]);
    }
}


//2
var array2 = [-2, 5, -9, 15, 0, 4];
var sum = 0;

for (var i = 0; i < array2.length; i++) {
    if (array2[i] > 0) {
        sum += array2[i];
    }
}

console.log("Сумма положительных элементов массива:", sum);



//3
var array3 = [1, 2, 5, 9, 4, 13, 4, 10];

for (var i = 0; i < array3.length; i++) {
    if (array3[i] === 4) {
        console.log('Есть!');
        break;
    }
}



//4
var array4 = [10, 20, 30, 50, 235, 3000];

for (var i = 0; i < array4.length; i++) {
    var firstDigit = parseInt(array4[i].toString()[0]);
    if (firstDigit === 1 || firstDigit === 2 || firstDigit === 5) {
        console.log(array4[i]);
    }
}



//5
var array5 = [1, 2, 3, 4, 5, 6, 7, 8, 9];
var resultString = '-';

for (var i = 0; i < array5.length; i++) {
    resultString += array5[i] + '-';
}

console.log(resultString);



//6
var daysOfWeek = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];

for (var i = 0; i < daysOfWeek.length; i++) {
    if (i >= 5) {
        console.log('**' + daysOfWeek[i] + '**');
    } else {
        console.log(daysOfWeek[i]);
    }
}


//7
var daysOfWeek2 = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
var currentDay = 'Среда'; 

for (var i = 0; i < daysOfWeek2.length; i++) {
    if (daysOfWeek2[i] === currentDay) {
        console.log('*' + daysOfWeek2[i] + '*');
    } else {
        console.log(daysOfWeek2[i]);
    }
}



//8
var n = 1000;
var num = 0;

while (n >= 50) {
    n /= 2;
    num++;
}

console.log("Получившееся число:", n);
console.log("Количество итераций:", num);

